<?PHP
$template['id']="iconmoon-single";
$template['name']=" 图月志单栏";
$template['author']="JJ Ying";
$template['intro']="Designed by JJ.Ying     http://IconMoon.com";
$template['dirname']="iconmoon-single";
$template['thumbnail']="thumb.jpg";
$template['structure']="template/iconmoon-single/elements.php";
$template['images']="template/iconmoon-single/images";
$template['css'][0]="template/iconmoon-single/styles.css";