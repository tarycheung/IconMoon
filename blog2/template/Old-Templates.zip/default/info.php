<?PHP
$template['id']="60A13BBE-C069-47A1-B210-C69C40CAAA00";
$template['sysver']='5.2';
$template['name']="Default";
$template['author']="Bo-blog";
$template['intro']="Default skin of Bo-blog 2.1.0.";
$template['dirname']="default";
$template['thumbnail']="thumb.jpg";
$template['structure']="template/default/elements.php";
$template['images']="template/default/images";
$template['moreimages']="template/default/images";
$template['css'][0]="template/default/styles.css";