<?PHP
$template['id']="IconMoon";
$template['name']="IconMoon";
$template['author']="JJ.Ying";
$template['intro']="Designed by JJ.Ying     http://IconMoon.com";
$template['dirname']="iconmoon";
$template['thumbnail']="thumb.jpg";
$template['structure']="template/iconmoon/elements.php";
$template['images']="template/iconmoon/images";
$template['css'][0]="template/iconmoon/styles.css";